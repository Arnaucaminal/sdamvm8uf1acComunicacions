package com.acaminal.comunicacions;

import android.content.Context;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Uri;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Patterns;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.acaminal.comunicacions.R;

public class MainActivity extends AppCompatActivity {

    private TextView connectionStatusTextView;
    private Button checkConnectionButton;
    private EditText urlEditText;
    private Button openUrlButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        connectionStatusTextView = findViewById(R.id.connectionStatusTextView);
        checkConnectionButton = findViewById(R.id.checkConnectionButton);
        urlEditText = findViewById(R.id.urlEditText);
        openUrlButton = findViewById(R.id.openUrlButton);

        checkConnectionButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                checkNetworkConnection();
            }
        });

        urlEditText.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                // Verificar si la URL és vàlida i habilitar/deshabilitar el botó "Obrir URL"
                String url = s.toString();
                boolean isValidUrl = Patterns.WEB_URL.matcher(url).matches();
                openUrlButton.setEnabled(isValidUrl);
            }

            @Override
            public void afterTextChanged(Editable s) {
            }
        });

        openUrlButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String url = urlEditText.getText().toString();
                openUrlInBrowser(url);
            }
        });
    }

    private void checkNetworkConnection() {
        ConnectivityManager connectivityManager = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);

        NetworkInfo activeNetwork = connectivityManager.getActiveNetworkInfo();
        boolean isConnected = activeNetwork != null && activeNetwork.isConnectedOrConnecting();

        if (isConnected) {
            if (activeNetwork.getType() == ConnectivityManager.TYPE_WIFI) {
                connectionStatusTextView.setText("Connexió Wi-Fi activa");
            } else if (activeNetwork.getType() == ConnectivityManager.TYPE_MOBILE) {
                connectionStatusTextView.setText("Connexió de Dades Mòbils activa");
            }
        } else {
            connectionStatusTextView.setText("Sense connexió de xarxa");
        }
    }

    private void openUrlInBrowser(String url) {
        Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
        startActivity(intent);
    }
}